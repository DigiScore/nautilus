from distutils.core import setup

setup(name='nautilus-v03',
      version='1.0',
      py_modules=['nautilus-v03'],
      author='Craig Vear',
      author_email='cvear@dmu.ac.uk',

      )